# Project:Restaurant Review App

## Contents:
    *Data(restaurants.json)
    *js files(dbhelper.js,main.js,restaurant_html.js)
    *Css file(restaurant.css)
    *HTML files(index.html,restaurant.html)

### --------------------------------------------------------------
This app  is created as part of the Udacity Nanodegree "Mobile Web Specialist". The project is divided into two stages.

#### Stage 1 focuses on 

- accessibility
- responsiveness
- offline first

#### Stage 2 focuses on

- performance
- accessibility

## Features

- View all restaurants
- View restaurants for a specific district or cuisine
- View details to a restaurant like opening hours and reviews
- Write reviews for a restaurant
- Mark a restaurant as favorite
- View already loaded pages also in offline mode
- Accessibility: Use the app with screen reader or keyboard-only-

## How to Run
1.  python -m SimpleHTTPServer 8000 

## Review Notes
- Map loads when online
- Did not see the restaurants.json issue, but it was missing from the cache. Error was seen when attempting to use the site offline?
- Added restaurants.json to the cache

### Note about ES6

Most of the code in this project has been written to the ES6 JavaScript specification for compatibility with modern web browsers and future proofing JavaScript code.

